			
declare @d1 datetime;declare @diff int;declare @indx int ;
declare @curr_tracefilename varchar(500); 
declare @base_tracefilename varchar(500); 

select @curr_tracefilename = path from sys.traces where is_default = 1 ; set @curr_tracefilename = reverse(@curr_tracefilename)
select @indx  = PATINDEX('%\%', @curr_tracefilename); set @curr_tracefilename = reverse(@curr_tracefilename)
set @base_tracefilename = LEFT( @curr_tracefilename,len(@curr_tracefilename) - @indx) + '\log.trc';

select databasename,
--convert(varchar(10),starttime,103) Date,
sum(case EventClass when 92 then  integerdata else 0 end) DataFileGrowth,
sum(case EventClass when 93 then IntegerData else 0 end) LOGFIleGrowth

        

FROM    sys.fn_trace_gettable
--(CONVERT(VARCHAR(150), ( SELECT TOP 1
   --                                                           f.[value]
--                                                      FROM    sys.fn_trace_getinfo(NULL) f
   --                                                   WHERE   f.property = 2
           --                                         )), DEFAULT) T
(@base_tracefilename , DEFAULT) T
        JOIN sys.trace_events TE ON T.EventClass = TE.trace_event_id
        --JOIN sys.trace_subclass_values V ON V.trace_event_id = TE.trace_event_id                                    AND V.subclass_value = T.EventSubClasslprestigte
											
WHERE  

		( te.trace_event_id in (92,93)
            )
group by databasename
