
DECLARE @total_buffer BIGINT;
SELECT @total_buffer = cntr_value
FROM sys.dm_os_performance_counters
WHERE RTRIM([object_name]) LIKE '%Buffer Manager'
AND counter_name = 'Database pages'
print @total_buffer
--/AND counter_name = 'Database pages' � Uncomment this line & comment the above line, if you're SQL Server version is 2012 or above/
;WITH BufCount AS
(
SELECT
database_id, db_buffer_pages = COUNT_BIG(*)
FROM sys.dm_os_buffer_descriptors
WHERE database_id BETWEEN 5 AND 32766
GROUP BY database_id
)
SELECT top 5
[Database_Name] = CASE [database_id] WHEN 32767
THEN 'MSSQL System Resource DB'
ELSE DB_NAME([database_id]) END,
[Database_ID],
db_buffer_pages as [Buffer Count (8KB Pages)],
[Buffer Size (MB)] = db_buffer_pages / 128,
[Buffer Size (%)] = CONVERT(DECIMAL(10,2), db_buffer_pages* 100.0 / @total_buffer)
FROM BufCount
ORDER BY [Buffer Size (%)] DESC;
