USE master;
GO
CREATE MASTER KEY ENCRYPTION
       BY PASSWORD='LS1setup!';
GO
--Step 2: Create a Certificate to support TDE
USE master;
GO 
CREATE CERTIFICATE TDE_Certificate_kdssg
       WITH SUBJECT='Certificate for TDE';
GO
--Step 3: Create Database Encryption Key

Create database TDE_enabled_kdssg_1
USE TDE_enabled_kdssg_1
GO
CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER CERTIFICATE TDE_Certificate_kdssg;  
--Step 4: Enable TDE on Database
ALTER DATABASE TDE_enabled_kdssg_1 SET ENCRYPTION ON;
GO
--Step 5: Backup the Certificate
--This step is not required to encrypt a database using TDE.  But to make sure you can recover your encrypted data from a database backup, should your instance database become corrupted, or you want to move an encrypted database to another server, you should backup the certificate.  To accomplish that backup run the following code:

USE master;
GO
BACKUP CERTIFICATE TDE_CERT_For_MyData
TO FILE = 'C:\temp\TDE_Cert_For_MyData.cer'
WITH PRIVATE KEY (file='C:\temp\TDE_CertKey.pvk',
ENCRYPTION BY PASSWORD='Provide Strong Password for Backup Here');