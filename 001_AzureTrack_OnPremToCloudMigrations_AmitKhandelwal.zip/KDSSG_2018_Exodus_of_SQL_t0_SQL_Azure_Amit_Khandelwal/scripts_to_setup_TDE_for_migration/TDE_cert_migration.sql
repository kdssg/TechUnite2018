USE master
GO
-- see all the databases with the TDE cert.
SELECT db.name as [database_name], cer.name as [certificate_name]
FROM sys.dm_database_encryption_keys dek
LEFT JOIN sys.certificates cer
ON dek.encryptor_thumbprint = cer.thumbprint
INNER JOIN sys.databases db
ON dek.database_id = db.database_id
WHERE dek.encryption_state = 3

--export the certificate to .cer and .pvk files

USE master;
GO
BACKUP CERTIFICATE TDE_Certificate_kdssg
TO FILE = 'D:\temp\TDE_Cert.cer'
WITH PRIVATE KEY (file='D:\temp\TDE_Cert.pvk',
ENCRYPTION BY PASSWORD='PassW0rd!');

--command to run in command prompt to cover pvk and cer files into pfx
--C:\Program Files (x86)\Windows Kits\10\bin\10.0.16299.0\x86>pvk2pfx -pvk D:/temp/TDE_Certkey.pvk  -pi "PassW0rd!" -spc d:/temp/TDE_Cert_for_mydata.cer -pfx d:/temp/TDE_Cert.pfx

--copy the Pfx file created to the jumpserver.
--RUn the powershell command in the jump server.

--now backup the database to URL and see if the backup up works this time
BACKUP DATABASE  TDE_enabled_kdssg
TO URL ='https://testbeddiag430.blob.core.windows.net/backup/TDE_enabled_kdssg_1.bak'
  WITH CREDENTIAL = 'Backupcredential', STATS = 10
GO 