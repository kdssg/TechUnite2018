--Backup to URL 
CREATE CREDENTIAL Backupcredential  
WITH IDENTITY= 'testbeddiag430'
, SECRET = 'UcRWcK79bgvbA8ONSwjSZEaOQjAp31bzBjOtk+b6dzNBzuXUelfI2wy6HPpyORiPXkawczVrOVlvl+G04ZrrpA=='

BACKUP DATABASE  AdventureWorks2012
TO URL ='https://testbeddiag430.blob.core.windows.net/backup/AdventureWorks2012.bak'
  WITH CREDENTIAL = 'Backupcredential', STATS = 10
GO 


--run this on the MI instance 
RESTORE DATABASE [AdventureWorks2012] FROM URL =
  'https://testbeddiag430.blob.core.windows.net/backup/AdventureWorks2012.bak'